import csv
import os
from datetime import datetime

# File to store expenses
FILE_NAME = "expenses.csv"

# Create file with headers if not exists
def initialize_file():
    if not os.path.exists(FILE_NAME):
        with open(FILE_NAME, mode="w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["Date", "Amount", "Category", "Description"])


def add_expense():
    try:
        amount = float(input("Enter amount: "))
        category = input("Enter category (Food, Travel, Bills, Other): ")
        description = input("Enter description: ")
        date = datetime.now().strftime("%Y-%m-%d")

        with open(FILE_NAME, mode="a", newline="") as file:
            writer = csv.writer(file)
            writer.writerow([date, amount, category, description])

        print("Expense added successfully!\n")

    except ValueError:
        print("Invalid amount! Please enter numbers only.\n")


def view_expenses():
    print("\n----- All Expenses -----")
    try:
        with open(FILE_NAME, mode="r") as file:
            reader = csv.reader(file)
            next(reader)  # skip header
            for row in reader:
                print(row)
    except FileNotFoundError:
        print("No expense records found.")
    print()


def total_expenses():
    total = 0
    try:
        with open(FILE_NAME, mode="r") as file:
            reader = csv.reader(file)
            next(reader)
            for row in reader:
                total += float(row[1])
    except:
        pass

    print(f"\nTotal Expenses: ₹{total}\n")


def category_summary():
    categories = {}

    try:
        with open(FILE_NAME, mode="r") as file:
            reader = csv.reader(file)
            next(reader)
            for row in reader:
                category = row[2]
                amount = float(row[1])
                categories[category] = categories.get(category, 0) + amount
    except:
        pass

    print("\n---- Category-wise Summary ----")
    for cat, amt in categories.items():
        print(f"{cat}: ₹{amt}")
    print()


# Main Menu
def main():
    initialize_file()

    while True:
        print("========== Expense Tracker ==========")
        print("1. Add Expense")
        print("2. View All Expenses")
        print("3. Total Expenses")
        print("4. Category Summary")
        print("5. Exit")
        choice = input("Enter your choice: ")

        if choice == "1":
            add_expense()
        elif choice == "2":
            view_expenses()
        elif choice == "3":
            total_expenses()
        elif choice == "4":
            category_summary()
        elif choice == "5":
            print("Exiting program...")
            break
        else:
            print("Invalid choice! Try again.\n")


if __name__ == "__main__":
    main()
